//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CnLigrAY.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/checkout",
			"/shop",
			"/info/$page",
			"/product/$slug"
		],
		preloads: [
			"/assets/index-DYZPc0ct.js",
			"/assets/link-CbLTYCOY.js",
			"/assets/preload-helper-jlSy_e5T.js",
			"/assets/photo-C9fTVzHJ.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DYZPc0ct.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BLCa320d.js", "/assets/product-card-Ct_H5AAg.js"]
	},
	"/checkout": {
		filePath: "/workspace/src/routes/checkout.tsx",
		children: void 0,
		preloads: ["/assets/checkout-CIKhaSaP.js"]
	},
	"/shop": {
		filePath: "/workspace/src/routes/shop.tsx",
		children: void 0,
		preloads: ["/assets/shop-DFCZeZ6T.js", "/assets/product-card-Ct_H5AAg.js"]
	},
	"/info/$page": {
		filePath: "/workspace/src/routes/info.$page.tsx",
		children: void 0,
		preloads: ["/assets/info._page-CTn8NjWB.js"]
	},
	"/product/$slug": {
		filePath: "/workspace/src/routes/product.$slug.tsx",
		children: void 0,
		preloads: ["/assets/product._slug-Cz9Uhliw.js", "/assets/product-card-Ct_H5AAg.js"]
	}
} });
//#endregion
export { tsrStartManifest };
