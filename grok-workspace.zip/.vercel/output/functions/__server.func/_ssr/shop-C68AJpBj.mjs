import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as searchProducts, l as products, t as categories } from "./money-DSNzNKzw.mjs";
import { i as Route$2, o as cn } from "./router-CGgd8cov.mjs";
import { t as ProductCard } from "./product-card-Ck8RQois.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shop-C68AJpBj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ShopPage() {
	const { category, q } = Route$2.useSearch();
	const navigate = Route$2.useNavigate();
	const [sort, setSort] = (0, import_react.useState)("shelf");
	const active = categories.find((item) => item.id === category);
	const items = (0, import_react.useMemo)(() => {
		const copy = [...searchProducts(q, category)];
		if (sort === "price-asc") copy.sort((a, b) => a.price - b.price);
		if (sort === "price-desc") copy.sort((a, b) => b.price - a.price);
		if (sort === "name") copy.sort((a, b) => a.name.localeCompare(b.name));
		return copy;
	}, [
		category,
		q,
		sort
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "wrap py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "eyebrow",
				children: "Catalogue"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl md:text-6xl",
				children: active ? active.name : "All pieces"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 max-w-xl text-sm text-muted",
				children: [
					active ? active.blurb : "Ten sample pieces. Filter by room, or search the names.",
					" ",
					products.length,
					" records in the prototype. None are live supplier listings."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex gap-2 overflow-x-auto pb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("btn btn-line shrink-0", category === "all" && "border-gold text-gold-2"),
					onClick: () => navigate({ search: {
						category: "all",
						q
					} }),
					children: "All"
				}), categories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("btn btn-line shrink-0", category === item.id && "border-gold text-gold-2"),
					onClick: () => navigate({ search: {
						category: item.id,
						q
					} }),
					children: item.name
				}, item.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field max-w-sm flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "eyebrow",
						children: "Search"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: q,
						onChange: (event) => navigate({ search: {
							category,
							q: event.target.value
						} }),
						placeholder: "Name or material"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field w-full sm:w-52",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "eyebrow",
						children: "Sort"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "select",
						value: sort,
						onChange: (event) => setSort(event.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "shelf",
								children: "Shelf order"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "price-asc",
								children: "Price, low to high"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "price-desc",
								children: "Price, high to low"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "name",
								children: "Name"
							})
						]
					})]
				})]
			}),
			items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-16 text-muted",
				children: "Nothing in this sample matches. Try another room."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3",
				children: items.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product }, product.id))
			})
		]
	});
}
//#endregion
export { ShopPage as component };
