import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as infoPages, r as Route$1, s as getInfoPage } from "./router-CGgd8cov.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/info._page-nTWUjhfJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function InfoRoute() {
	const { page } = Route$1.useParams();
	const info = getInfoPage(page);
	const [note, setNote] = (0, import_react.useState)("");
	const [kept, setKept] = (0, import_react.useState)(false);
	if (!info) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "wrap py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl",
			children: "That page is not here"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "btn btn-line mt-6",
			children: "Back home"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "wrap py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "eyebrow",
				children: info.kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl md:text-6xl",
				children: info.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 max-w-2xl space-y-4 text-base leading-relaxed text-muted",
				children: info.paragraphs.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: paragraph }, paragraph))
			}),
			info.slug === "contact" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 grid max-w-xl gap-4",
				onSubmit: (event) => {
					event.preventDefault();
					if (note.trim().length < 2) return;
					setKept(true);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: ["Note", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: note,
							onChange: (event) => setNote(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "btn btn-line w-fit",
						children: "Keep on this screen"
					}),
					kept && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-gold-2",
						"aria-live": "polite",
						children: "Kept on this screen only. It was not sent, and it will disappear when you leave."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-12 flex flex-wrap gap-4 text-sm text-faint",
				children: infoPages.filter((item) => item.slug !== info.slug).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/info/$page",
					params: { page: item.slug },
					className: "hover:text-fg",
					children: item.title
				}) }, item.slug))
			})
		]
	});
}
//#endregion
export { InfoRoute as component };
