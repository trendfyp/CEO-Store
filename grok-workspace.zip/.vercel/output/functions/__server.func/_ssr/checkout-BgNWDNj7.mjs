import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as useCommerceReady, h as useCart, i as getProductById, o as merchandiseOf, s as money, v as variantOf } from "./money-DSNzNKzw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout-BgNWDNj7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function beginCheckout(draft) {
	return {
		ok: false,
		code: "unconfigured",
		message: "No payment provider is configured. Nothing was charged, and no order was sent to a supplier.",
		draft
	};
}
var empty = {
	name: "",
	email: "",
	phone: "",
	city: "",
	address: "",
	note: ""
};
function CheckoutPage() {
	const ready = useCommerceReady();
	const lines = useCart((state) => state.lines);
	const visible = ready ? lines : [];
	const merchandise = merchandiseOf(visible);
	const [contact, setContact] = (0, import_react.useState)(empty);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [message, setMessage] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(false);
	const set = (key) => (event) => {
		setContact((current) => ({
			...current,
			[key]: event.target.value
		}));
	};
	const submit = async (event) => {
		event.preventDefault();
		const nextErrors = [];
		if (contact.name.trim().length < 2) nextErrors.push("Add the name that would receive a parcel.");
		if (!contact.email.includes("@") || contact.email.trim().length < 5) nextErrors.push("Add an email address.");
		if (contact.city.trim().length < 2) nextErrors.push("Add a city.");
		if (contact.address.trim().length < 4) nextErrors.push("Add a street address.");
		if (visible.length === 0) nextErrors.push("The bag is empty.");
		setErrors(nextErrors);
		if (nextErrors.length > 0) return;
		const next = {
			id: `demo_${Date.now()}`,
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			status: "demo_unpaid",
			contact,
			merchandise,
			lines: visible.flatMap((line) => {
				const product = getProductById(line.productId);
				const variant = product ? variantOf(product, line.variantId) : void 0;
				if (!product || !variant) return [];
				return [{
					productId: product.id,
					variantId: variant.id,
					name: product.name,
					variant: variant.label,
					qty: line.qty,
					unitPrice: product.price
				}];
			})
		};
		setPending(true);
		const result = await beginCheckout(next);
		setPending(false);
		setDraft(result.draft);
		setMessage(result.message);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "wrap py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "eyebrow",
				children: "Demo only"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl md:text-6xl",
				children: "Checkout"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 border border-gold/40 bg-surface p-4 text-sm leading-relaxed text-muted",
				children: "This is not a payment page. Card numbers are not collected. Submitting does not charge anyone and does not create an order. A provider is not assumed — not Stripe, PayPal, or Chapa."
			}),
			visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Nothing is in the bag."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop",
					search: {
						category: "all",
						q: ""
					},
					className: "btn btn-gold mt-6",
					children: "Return to the shop"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-10 md:grid-cols-[1.2fr_0.8fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					noValidate: true,
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: contact.name,
								onChange: set("name"),
								autoComplete: "name"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: contact.email,
								onChange: set("email"),
								autoComplete: "email",
								inputMode: "email"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: ["Phone, optional", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: contact.phone,
								onChange: set("phone"),
								autoComplete: "tel",
								inputMode: "tel"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: ["City", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: contact.city,
								onChange: set("city"),
								autoComplete: "address-level2"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: ["Address", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: contact.address,
								onChange: set("address"),
								autoComplete: "street-address"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: ["Note", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: contact.note,
								onChange: set("note")
							})]
						}),
						errors.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "text-sm text-danger",
							children: errors.map((error) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: error }, error))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "btn btn-gold",
							disabled: pending,
							children: pending ? "Checking" : "Review unpaid draft"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs leading-relaxed text-faint",
							children: "Contact details stay on this screen only. They are not saved in the browser and they are not sent."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "border border-line p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl",
							children: "Bag"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-3 text-sm",
							children: visible.map((line) => {
								const product = getProductById(line.productId);
								const variant = product ? variantOf(product, line.variantId) : void 0;
								if (!product || !variant) return null;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [product.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-faint",
										children: [
											variant.label,
											" · ",
											line.qty
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: money(product.price * line.qty)
									})]
								}, `${line.productId}-${line.variantId}`);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-2 border-t border-line pt-4 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Merchandise" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: money(merchandise)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-faint",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Shipping" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Not calculated" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-faint",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Charged" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: money(0)
									})]
								})
							]
						})
					]
				})]
			}),
			draft && message && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 border border-line p-5",
				"aria-live": "polite",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Not placed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-4xl",
						children: "No order exists"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted",
						children: message
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-faint",
						children: [
							"Reference ",
							draft.id,
							" · status ",
							draft.status,
							" · merchandise ",
							money(draft.merchandise),
							" · charged",
							" ",
							money(0)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 max-w-2xl text-sm leading-relaxed text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Before a real launch, confirm each of these. None of them is done here:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-3 list-disc space-y-2 pl-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A seller of record, and a merchant account that has actually been approved." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A settlement currency and a bank that can receive it from Ethiopia." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Payment confirmation on a server, after a webhook — never a success screen in the browser." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Verified supplier product ids, real costs, and a carrier with a price." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A returns window you can honor, and a support address you will read." })
							]
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { CheckoutPage as component };
