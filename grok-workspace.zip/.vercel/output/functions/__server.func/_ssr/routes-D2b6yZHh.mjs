import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getProductBySlug, c as pairings, f as stockOf, l as products, s as money, t as categories, y as withFlag } from "./money-DSNzNKzw.mjs";
import { a as Photo, o as cn } from "./router-CGgd8cov.mjs";
import { t as ProductCard } from "./product-card-Ck8RQois.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D2b6yZHh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FEATURED = "halo-arc";
var DUST = [
	0,
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10,
	11
];
function Hero() {
	const product = getProductBySlug(FEATURED);
	const rig = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const node = rig.current;
		const stage = node?.parentElement;
		if (!node || !stage) return;
		let raf = 0;
		let pointerX = 0;
		let pointerY = 0;
		let usingPointer = false;
		let tiltX = 0;
		let tiltY = 0;
		let usingTilt = false;
		let running = true;
		const paint = (time) => {
			if (!running) return;
			const drift = reduce ? 0 : Math.sin(time / 1800) * 12;
			const ry = usingPointer ? pointerX * 18 : usingTilt ? tiltY : drift;
			const rx = usingPointer ? pointerY * -12 : usingTilt ? tiltX : 7;
			const bob = reduce ? 0 : Math.sin(time / 1400) * 8;
			node.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg) translateY(${bob}px)`;
			raf = requestAnimationFrame(paint);
		};
		const onPointer = (event) => {
			const rect = stage.getBoundingClientRect();
			pointerX = (event.clientX - rect.left) / rect.width - .5;
			pointerY = (event.clientY - rect.top) / rect.height - .5;
			usingPointer = true;
		};
		const onLeave = () => {
			usingPointer = false;
		};
		const onOrient = (event) => {
			if (usingPointer) return;
			const gamma = event.gamma ?? 0;
			const beta = event.beta ?? 45;
			if (gamma === 0 && beta === 0) return;
			usingTilt = true;
			tiltY = Math.max(-18, Math.min(18, gamma / 4));
			tiltX = Math.max(-12, Math.min(12, (beta - 45) / 5));
		};
		stage.addEventListener("pointermove", onPointer);
		stage.addEventListener("pointerleave", onLeave);
		window.addEventListener("deviceorientation", onOrient);
		raf = requestAnimationFrame(paint);
		return () => {
			running = false;
			cancelAnimationFrame(raf);
			stage.removeEventListener("pointermove", onPointer);
			stage.removeEventListener("pointerleave", onLeave);
			window.removeEventListener("deviceorientation", onOrient);
		};
	}, []);
	if (!product) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "hero wrap grid items-center gap-8 py-8 md:grid-cols-2 md:py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "eyebrow rise",
				children: "Sample showroom"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "rise rise-2 mt-4 font-display text-5xl text-fg md:text-7xl",
				children: ["Objects,", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block text-gold-2 italic",
					children: "considered."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rise rise-3 mt-6 max-w-md text-base text-muted md:text-lg",
				children: "A quiet catalogue of lamps, sound, and small instruments. Prices are samples in US dollars. Nothing here is a live supplier listing, and nothing can be paid for yet."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise rise-4 mt-8 flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop",
					search: {
						category: "all",
						q: ""
					},
					className: "btn btn-gold",
					children: "Enter the showroom"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/product/$slug",
					params: { slug: product.slug },
					className: "btn btn-line",
					children: ["View the ", product.name]
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stage stage-box relative mx-auto w-full max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute inset-0",
					"aria-hidden": true,
					children: DUST.map((index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `dust dust-${index}` }, index))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "orbit",
					"aria-hidden": true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: rig,
					className: "rig absolute inset-x-8 top-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: product.image,
						alt: `${product.name}, the featured sample`,
						width: 1200,
						height: 1600,
						className: "hero-photo mx-auto w-auto object-contain"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: product.image,
						alt: "",
						"aria-hidden": true,
						className: "reflection hero-reflect mx-auto object-contain"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pedestal absolute right-0 bottom-8 left-0",
					"aria-hidden": true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "absolute right-0 bottom-0 left-0 text-center text-xs tracking-widest text-faint uppercase",
					children: ["Move or tilt · ", product.name]
				})
			]
		})]
	});
}
function Reveal({ children, className }) {
	const ref = (0, import_react.useRef)(null);
	const [inView, setInView] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			setInView(true);
			return;
		}
		const observer = new IntersectionObserver(([entry]) => {
			if (entry?.isIntersecting) {
				setInView(true);
				observer.disconnect();
			}
		}, {
			threshold: .12,
			rootMargin: "0px 0px -6% 0px"
		});
		observer.observe(el);
		return () => observer.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: cn("reveal", inView && "reveal-in", className),
		children
	});
}
function HomePage() {
	const featured = withFlag("featured");
	const popular = withFlag("popular");
	const trending = withFlag("trending");
	const bestsellers = withFlag("bestseller");
	const lead = featured[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "wrap py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Featured"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl md:text-5xl",
					children: "The first shelf"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop",
					search: {
						category: "all",
						q: ""
					},
					className: "text-sm text-gold",
					children: "All pieces"
				})]
			}), lead && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-6 md:grid-cols-[1.4fr_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/product/$slug",
					params: { slug: lead.slug },
					className: "group block bg-surface",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
						src: lead.image,
						alt: lead.name,
						className: "feature-lead",
						priority: true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between gap-4 p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-4xl",
							children: lead.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: lead.tagline
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tabular-nums",
							children: money(lead.price)
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-6",
					children: featured.slice(1).map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/product/$slug",
						params: { slug: product.slug },
						className: "grid grid-cols-[7rem_1fr] gap-4 bg-surface p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
							src: product.image,
							alt: "",
							className: "ratio-product"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex flex-col justify-end py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-3xl",
									children: product.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 text-sm text-muted",
									children: product.tagline
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-3 tabular-nums",
									children: money(product.price)
								})
							]
						})]
					}, product.id))
				})]
			})]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "wrap py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Popular"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl md:text-5xl",
					children: "Often opened"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3",
					children: popular.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product }, product.id))
				})
			]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "py-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "wrap",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Trending"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl md:text-5xl",
					children: "Moving through the room"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rail mt-8 flex gap-4 overflow-x-auto pb-2",
				children: trending.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/product/$slug",
					params: { slug: product.slug },
					className: "w-64 shrink-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
							src: product.image,
							alt: product.name,
							className: "ratio-product"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-3xl",
							children: product.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [money(product.price), " · sample"]
						})
					]
				}, product.id))
			})]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "wrap py-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Categories"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl md:text-5xl",
					children: "Choose a room"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid grid-cols-2 gap-3 md:grid-cols-3",
					children: categories.map((category) => {
						const cover = products.find((product) => product.categoryId === category.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/shop",
							search: {
								category: category.id,
								q: ""
							},
							className: "group relative block overflow-hidden bg-surface",
							children: [
								cover && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
									src: cover.image,
									alt: "",
									className: "ratio-product"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "scrim absolute inset-0" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "absolute inset-x-0 bottom-0 p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-display text-3xl",
										children: category.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-muted",
										children: category.blurb
									})]
								})
							]
						}, category.id);
					})
				})
			]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "wrap py-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Best sellers"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl md:text-5xl",
					children: "Asked for twice"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-8 divide-y divide-line border-y border-line",
					children: bestsellers.map((product, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/product/$slug",
						params: { slug: product.slug },
						className: "grid grid-cols-[2rem_4.5rem_1fr_auto] items-center gap-4 py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-faint tabular-nums",
								children: ["0", index + 1]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
								src: product.image,
								alt: "",
								className: "ratio-product"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-display text-3xl",
								children: product.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-muted",
								children: [stockOf(product), " in the sample catalogue"]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: money(product.price)
							})
						]
					}) }, product.id))
				})
			]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "wrap py-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Pairings"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl md:text-5xl",
					children: "Shown together"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-xl text-sm text-muted",
					children: "Suggestions only. There is no discount, no countdown, and no promotional price. Each total is the sum of the sample prices."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-4 md:grid-cols-3",
					children: pairings.map((pairing) => {
						const pieces = pairing.slugs.map((slug) => getProductBySlug(slug)).filter((item) => item != null);
						const sum = pieces.reduce((total, item) => total + item.price, 0);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "border border-line p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-3xl",
									children: pairing.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted",
									children: pairing.text
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-4 space-y-3",
									children: pieces.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/product/$slug",
										params: { slug: product.slug },
										className: "flex items-center justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: product.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "tabular-nums text-sm text-muted",
											children: money(product.price)
										})]
									}) }, product.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 border-t border-line pt-3 text-sm",
									children: ["Sum of samples ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: money(sum)
									})]
								})
							]
						}, pairing.id);
					})
				})
			]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "wrap grid gap-8 py-12 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Trust"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl",
					children: "What is true today"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-6 space-y-4 text-sm leading-relaxed text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Every piece is labeled as a sample. Supplier ids begin with SAMPLE and are not live listings." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The bag is saved on this device only. No card number is ever asked for." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Stock counts are the sample catalogue, not a warehouse feed and not a scarcity tactic." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A favorite heart does not create an account." })
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: [
					[
						"shipping",
						"Shipping",
						"Not calculated until a carrier exists."
					],
					[
						"returns",
						"Returns",
						"No sale means no return. The draft is published anyway."
					],
					[
						"support",
						"Support",
						"The contact form does not send."
					]
				].map(([page, title, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/info/$page",
					params: { page },
					className: "border border-line p-5 hover:border-gold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-display text-3xl",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-sm text-muted",
						children: text
					})]
				}, page))
			})]
		}) })
	] });
}
var SplitComponent = HomePage;
//#endregion
export { SplitComponent as component };
