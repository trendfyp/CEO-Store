import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useUi, f as stockOf, g as useCommerceReady, h as useCart, n as categoryById, p as useBagActions, r as defaultVariant, s as money } from "./money-DSNzNKzw.mjs";
import { l as Heart } from "../_libs/lucide-react.mjs";
import { a as Photo, o as cn } from "./router-CGgd8cov.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-card-Ck8RQois.js
var import_jsx_runtime = require_jsx_runtime();
function ProductCard({ product }) {
	const ready = useCommerceReady();
	const favorites = useCart((state) => state.favorites);
	const toggleFavorite = useCart((state) => state.toggleFavorite);
	const setQuick = useUi((state) => state.setQuick);
	const { addToBag } = useBagActions();
	const category = categoryById(product.categoryId);
	const variant = defaultVariant(product);
	const stock = stockOf(product);
	const saved = ready && favorites.includes(product.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "card flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card-frame relative overflow-hidden bg-surface",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/product/$slug",
				params: { slug: product.slug },
				className: "block",
				"aria-label": product.name,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
					src: product.image,
					alt: product.name,
					className: "ratio-product"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: cn("icon-btn absolute top-2 right-2 bg-bg/70", saved && "text-gold"),
				"aria-pressed": saved,
				"aria-label": saved ? `Remove ${product.name} from favorites` : `Save ${product.name}`,
				disabled: !ready,
				onClick: () => toggleFavorite(product.id),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: cn("size-4", saved && "fill-current") })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col gap-2 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest text-faint uppercase",
					children: category?.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-2xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/product/$slug",
						params: { slug: product.slug },
						className: "hover:text-gold-2",
						children: product.name
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: product.tagline
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-auto flex items-baseline justify-between gap-3 pt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-base",
						children: money(product.price)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-faint",
						children: stock > 0 ? `${stock} in sample` : "Unavailable"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-gold btn-compact mt-2 w-full",
					disabled: !ready || !variant || variant.stock < 1,
					onClick: () => variant && addToBag(product.id, variant.id, 1),
					children: variant && variant.stock > 0 ? "Add to bag" : "Unavailable"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-link mt-1",
					onClick: () => setQuick(product.id),
					children: "Quick view"
				})
			]
		})]
	});
}
//#endregion
export { ProductCard as t };
