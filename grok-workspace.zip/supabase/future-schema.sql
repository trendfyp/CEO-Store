-- VELORA future schema. Do not run this until you explicitly authorize a database.
-- Apply it in Supabase (or another Postgres) only after review.
-- NEVER put a service-role key, secret, or connection string in browser code
-- or in a public repository.

-- Profiles are 1:1 with auth users. Customers read and update only themselves.
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  display_name text,
  city text,
  created_at timestamptz not null default now()
);

create table if not exists public.categories (
  id text primary key,
  name text not null,
  blurb text not null default ''
);

create table if not exists public.products (
  id text primary key,
  slug text not null unique,
  category_id text not null references public.categories (id),
  name text not null,
  tagline text not null default '',
  description text not null default '',
  price_cents integer not null check (price_cents >= 0),
  currency text not null default 'USD',
  -- Internal. Not readable by the public policies below.
  cost_cents integer,
  supplier_product_id text,
  shipping_note text not null default '',
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.product_variants (
  id text primary key,
  product_id text not null references public.products (id) on delete cascade,
  label text not null,
  stock integer not null default 0 check (stock >= 0)
);

create table if not exists public.favorites (
  user_id uuid not null references auth.users (id) on delete cascade,
  product_id text not null references public.products (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);

-- status is never set to 'paid' by a customer. Only a server webhook
-- using the service role may record a verified payment.
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  status text not null default 'draft' check (status in ('draft', 'unpaid', 'paid', 'cancelled')),
  contact jsonb not null default '{}'::jsonb,
  merchandise_cents integer not null check (merchandise_cents >= 0),
  currency text not null default 'USD',
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders (id) on delete cascade,
  product_id text not null,
  variant_id text not null,
  name text not null,
  variant_label text not null,
  qty integer not null check (qty > 0),
  unit_price_cents integer not null check (unit_price_cents >= 0)
);

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_variants enable row level security;
alter table public.favorites enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

create policy "profiles are private to the owner"
  on public.profiles for select
  using (auth.uid() = id);

create policy "owner updates own profile"
  on public.profiles for update
  using (auth.uid() = id)
  with check (auth.uid() = id);

create policy "anyone reads categories"
  on public.categories for select
  using (true);

create policy "anyone reads published products"
  on public.products for select
  using (published = true);

create policy "anyone reads variants of published products"
  on public.product_variants for select
  using (
    exists (
      select 1 from public.products p
      where p.id = product_id and p.published = true
    )
  );

create policy "favorites are private"
  on public.favorites for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "orders are private to the owner"
  on public.orders for select
  using (auth.uid() = user_id);

-- Customers may insert only their own unpaid draft. They cannot insert status 'paid'.
create policy "owner inserts an unpaid draft"
  on public.orders for insert
  with check (auth.uid() = user_id and status in ('draft', 'unpaid'));

create policy "owner reads own order items"
  on public.order_items for select
  using (
    exists (
      select 1 from public.orders o
      where o.id = order_id and o.user_id = auth.uid()
    )
  );

create policy "owner inserts items on own unpaid order"
  on public.order_items for insert
  with check (
    exists (
      select 1 from public.orders o
      where o.id = order_id
        and o.user_id = auth.uid()
        and o.status in ('draft', 'unpaid')
    )
  );

-- Intentionally no client update policy on orders.status.
-- Payment confirmation belongs to a service-role webhook, not the browser.
