import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useUi, a as getProductBySlug, g as useCommerceReady, h as useCart, n as categoryById, p as useBagActions, r as defaultVariant, s as money, u as relatedProducts, v as variantOf } from "./money-DSNzNKzw.mjs";
import { l as Heart, o as Plus, s as Minus } from "../_libs/lucide-react.mjs";
import { a as Photo, n as Route, o as cn } from "./router-CGgd8cov.mjs";
import { t as ProductCard } from "./product-card-Ck8RQois.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product._slug-FQUnqlsC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductView({ product }) {
	const ready = useCommerceReady();
	const navigate = useNavigate();
	const lines = useCart((state) => state.lines);
	const favorites = useCart((state) => state.favorites);
	const toggleFavorite = useCart((state) => state.toggleFavorite);
	const notify = useUi((state) => state.notify);
	const { addToBag } = useBagActions();
	const category = categoryById(product.categoryId);
	const initial = defaultVariant(product);
	const [variantId, setVariantId] = (0, import_react.useState)(initial?.id ?? "");
	const [qty, setQty] = (0, import_react.useState)(1);
	const [image, setImage] = (0, import_react.useState)(product.images[0] ?? product.image);
	const [zoom, setZoom] = (0, import_react.useState)(false);
	const [origin, setOrigin] = (0, import_react.useState)({
		x: 50,
		y: 50
	});
	const variant = variantOf(product, variantId) ?? initial;
	const saved = ready && favorites.includes(product.id);
	const related = relatedProducts(product);
	(0, import_react.useEffect)(() => {
		const next = defaultVariant(product);
		setVariantId(next?.id ?? "");
		setQty(1);
		setImage(product.images[0] ?? product.image);
		setZoom(false);
	}, [product]);
	if (!variant) return null;
	const changeQty = (next) => {
		if (!Number.isInteger(next)) return;
		if (next < 1) {
			setQty(1);
			return;
		}
		if (next > variant.stock) {
			setQty(Math.max(variant.stock, 1));
			notify(variant.stock > 0 ? `Only ${variant.stock} in this sample.` : "That finish is unavailable.");
			return;
		}
		setQty(next);
	};
	const buyNow = () => {
		if (!lines.some((line) => line.productId === product.id && line.variantId === variant.id)) {
			if (!addToBag(product.id, variant.id, qty, { open: false })) return;
		}
		navigate({ to: "/checkout" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "wrap py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-faint",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop",
						search: {
							category: "all",
							q: ""
						},
						className: "hover:text-fg",
						children: "Shop"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: " / "
					}),
					category && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop",
						search: {
							category: category.id,
							q: ""
						},
						className: "hover:text-fg",
						children: category.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: " / "
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: product.name
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-8 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "zoom-frame",
						onClick: () => setZoom(true),
						onMouseMove: (event) => {
							const rect = event.currentTarget.getBoundingClientRect();
							setOrigin({
								x: (event.clientX - rect.left) / rect.width * 100,
								y: (event.clientY - rect.top) / rect.height * 100
							});
						},
						"aria-label": `Enlarge ${product.name}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: image,
							alt: product.name,
							width: 1200,
							height: 1600,
							className: "zoom-img ratio-product w-full object-cover",
							style: {
								["--ox"]: `${origin.x}%`,
								["--oy"]: `${origin.y}%`
							}
						})
					}),
					product.images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex gap-2",
						children: product.images.map((src) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: cn("w-16 border", src === image ? "border-gold" : "border-line"),
							onClick: () => setImage(src),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
								src,
								alt: "",
								className: "ratio-product"
							})
						}, src))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-faint",
						children: "Tap the photograph to enlarge. One studio view is on file."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: category?.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-5xl md:text-6xl",
						children: product.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-lg text-muted",
						children: product.tagline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 font-display text-4xl tabular-nums",
						children: money(product.price)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-faint",
						children: "Sample price in USD. Not a local quote. No reference discount."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-muted",
						children: variant.stock > 0 ? `${variant.label}: ${variant.stock} in the sample catalogue.` : `${variant.label} is unavailable in this sample.`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 flex flex-wrap gap-2",
						role: "group",
						"aria-label": "Finish",
						children: product.variants.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-pressed": item.id === variant.id,
							className: cn("btn btn-line", item.id === variant.id && "border-gold text-gold-2"),
							onClick: () => {
								setVariantId(item.id);
								setQty(1);
							},
							children: [item.label, item.stock < 1 ? " · none" : ""]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center border border-line",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "icon-btn",
									"aria-label": "Decrease quantity",
									onClick: () => changeQty(qty - 1),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-8 text-center tabular-nums",
									children: qty
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "icon-btn",
									"aria-label": "Increase quantity",
									onClick: () => changeQty(qty + 1),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: cn("icon-btn border border-line", saved && "text-gold"),
							"aria-pressed": saved,
							"aria-label": saved ? "Remove favorite" : "Save favorite",
							disabled: !ready,
							onClick: () => toggleFavorite(product.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: cn("size-4", saved && "fill-current") })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-gold flex-1",
							disabled: !ready || variant.stock < 1,
							onClick: () => addToBag(product.id, variant.id, qty),
							children: variant.stock > 0 ? "Add to bag" : "Unavailable"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-line flex-1",
							disabled: !ready || variant.stock < 1,
							onClick: buyNow,
							children: "Buy now · demo"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 text-sm leading-relaxed text-muted",
						children: product.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 list-disc space-y-1 pl-5 text-sm text-muted",
						children: product.notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: note }, note))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 border border-line p-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Shipping"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-muted",
								children: product.shippingNote
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-faint",
								children: [
									"Supplier id ",
									product.fulfillment.supplierProductId,
									". Tracking reference:",
									" ",
									product.fulfillment.trackingRef ?? "none",
									"."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-faint",
								children: product.fulfillment.note
							})
						]
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl",
					children: "Related pieces"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 grid grid-cols-2 gap-4 md:grid-cols-3",
					children: related.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: item }, item.id))
				})]
			}),
			zoom && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lightbox",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": `${product.name} enlarged`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-line absolute top-4 right-4",
					onClick: () => setZoom(false),
					children: "Close"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: image,
					alt: product.name,
					className: "zoom-img is-zoomed",
					style: {
						["--ox"]: `${origin.x}%`,
						["--oy"]: `${origin.y}%`
					},
					onMouseMove: (event) => {
						const rect = event.currentTarget.getBoundingClientRect();
						setOrigin({
							x: (event.clientX - rect.left) / rect.width * 100,
							y: (event.clientY - rect.top) / rect.height * 100
						});
					}
				})]
			})
		]
	});
}
function ProductRoute() {
	const { slug } = Route.useParams();
	const product = getProductBySlug(slug);
	if (!product) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "wrap py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "eyebrow",
				children: "Missing"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl",
				children: "That piece is not in the sample catalogue."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/shop",
				search: {
					category: "all",
					q: ""
				},
				className: "btn btn-gold mt-8",
				children: "Back to the shop"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductView, { product });
}
//#endregion
export { ProductRoute as component };
